export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-black text-white">
      <header className="p-8 text-center">
        <h1 className="text-6xl font-bold mb-4">FreedomStyle</h1>
        <p className="text-xl">Modern Fashion Store</p>
      </header>
      
      <main className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center">
            <h3 className="text-2xl font-semibold mb-4">Clothes</h3>
            <p>Premium fashion for every occasion</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center">
            <h3 className="text-2xl font-semibold mb-4">Watches</h3>
            <p>Luxury timepieces and accessories</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center">
            <h3 className="text-2xl font-semibold mb-4">Shoes</h3>
            <p>Comfortable and stylish footwear</p>
          </div>
        </div>
        
        <div className="text-center">
          <h2 className="text-4xl font-bold mb-8">Featured Products</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
              <div key={i} className="bg-white rounded-lg overflow-hidden shadow-lg">
                <div className="h-48 bg-gray-200"></div>
                <div className="p-4 text-black">
                  <h3 className="font-semibold">Product {i}</h3>
                  <p className="text-blue-600 font-bold">PKR 4,500</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
      
      <footer className="bg-black/20 p-8 text-center">
        <p>Contact: freedomstylefs12@gmail.com | Phone: 03103805860</p>
      </footer>
    </div>
  );
}